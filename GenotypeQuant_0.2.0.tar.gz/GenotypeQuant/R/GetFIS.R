GetFIS<-function(Ref.Gen,All.nchar=3){
	
	requireNamespace("genepop")
	#export to Genepop from the data frame, my own function ----
	if(All.nchar==3){
		Ref.Gen[Ref.Gen==0]<-"000000"
	}else{if(All.nchar==2){Ref.Gen[Ref.Gen==0]<-"0000"
	}else{if(All.nchar==1){Ref.Gen[Ref.Gen==0]<-"00"}
	}
	}
	
	write(c("You can edit this line",names(Ref.Gen)),"GenepopIN",append=T)
	write("Pop","GenepopIN",append=T)
	N<-nrow(Ref.Gen)
	write.table(cbind(rep("Ref.Pop,",N),Ref.Gen),file="GenepopIN", append=T, quote=F, col.names=F,row.names=F )
	
	#using genepop to get FIS
	genepop::genedivFis("GenepopIN",outputFile="FIS.out",verbose=F)
	# 
	FIS.lines<-readLines("FIS.out")
	LociFisRows<-grep("All samples",FIS.lines)-2
	
	temp<-unlist(strsplit(FIS.lines[LociFisRows]," "))
	FIS.DF<-data.frame(matrix(temp[!(nchar(temp)==0 | temp=="Ref.Pop")],ncol=3,byrow=T))
	names(FIS.DF)<-c("1-Qintra","1-Qinter","Fis") #Use Qintra to sample correlated alleles when FIS is TRUE
	system2("rm","GenepopIN")
	system2("rm","FIS.out")
	
	return(apply(Fis,2,as.numeric))
}